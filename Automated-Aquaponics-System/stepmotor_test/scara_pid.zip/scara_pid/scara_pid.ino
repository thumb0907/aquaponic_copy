#include "set_motor.h"
#include "encoder.h"
#include "pid.h"
#include "move.h"


void setup() {
  Serial.begin(115200);
  motor_pin();
  set_tim();
  set_int();
}

void loop() {
  Serial.println(digitalRead(stop_z)); // 안누르면 1, 누르면 0 이 나오면 정상
  /*
  delay(5000);
  home();
  delay(200);
  goXY(120, 150);
  Serial.println("절대 이동1 완료");
  delay(100);
  moveXY_rel(10,30);
  Serial.println("상대이동1 완료");
  //delay(1000);
  moveXY_rel(-30, -50);
  Serial.println("상대이동2 완료");
  //delay(1000);
  */
  //delay(5);
  //move_j3_wait(-30);
  //move_j3_wait(30);
  //move_j2_continuous(false, 80000);
  
  //j4_home_stop_on_switch_safe(true, 2000);
  //delay(200);
  //move_j4_wait(30);
  //move_j4_wait(-30);

  //delay(10000);
  //delay(3000000);
  //while(1);   // 여기서 정지
  //delay(300000);
  //delay(30000);
  //home();
  //move_j2(7200.0f, 600000);
  //delay(3000000);
  /*
  Serial.print("A=");
  Serial.print(digitalRead(j4_A));
  Serial.print("  B=");
  Serial.print(digitalRead(j4_B));
  Serial.print("  pos=");
  Serial.println(j4_enc.pos);
  delay(50);
  */
  //moveRail(4000, 1);   // 한 방향으로 500pps로 계속 이동
  //delay(2000);
  //stopRail();            // 정지
  //home();
}


