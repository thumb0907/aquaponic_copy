#include "encoder.h"
#include "set_motor.h"
#include "pid.h"

float j2_pos_mm = 0.0f;
const float cpr    = 400.0f;
const float en_cnt = cpr * 2.0f;
const int j3_gear = 16;
const int j1_gear = 20;
const float j4_gear = 4.5;
volatile bool j1_run=false, j2_run=false, j3_run=false, j4_run=false;
static volatile bool j1_ps=false, j2_ps=false, j3_ps=false, j4_ps=false;

encod j1_enc = { j1_A, j1_B, 0 };
encod j3_enc = { j3_A, j3_B, 0 };
encod j4_enc = { j4_A, j4_B, 0 };

volatile bool j1pulseState = false;
volatile bool j3pulseState = false;
volatile bool j4pulseState = false;

volatile long j1pulseInterval = 100;
volatile long j3pulseInterval = 100;
volatile long j4pulseInterval = 100;

// z축 
const unsigned int PULSE_US = 10;   // 펄스폭은 넉넉히
const long PULSES_PER_REV = 800;  // (가정) 1.8°모터 + 128분주
float J2_LEAD_MM_PER_REV = (8.0f/1.0f);
unsigned long J2_DEFAULT_PPS =800000;   // j2 기본 속도
volatile bool j2_endstop_hit = false;

constexpr bool EN_ACTIVE_LOW = false; // 모터enable

//리니어 레일
volatile bool rail_run = false;
volatile bool railPulseState = false;
volatile long railPulseInterval = 100;


float encoder_getAngleDeg(const encod* e) {
  return -(e->pos) * 360.0f / en_cnt;
}

void set_tim()
{
  Timer1.initialize(50);
  Timer1.attachInterrupt(j1stepPulse);
  Timer4.initialize(50);
  Timer4.attachInterrupt(j3stepPulse);
  Timer3.initialize(50);
  Timer3.attachInterrupt(railStepPulse);
  Timer5.initialize(50);
  Timer5.attachInterrupt(j4stepPulse);
}

void set_int()
{
  attachInterrupt(digitalPinToInterrupt(j1_enc.pinA), j1EncoderA, CHANGE);
  attachInterrupt(digitalPinToInterrupt(j3_enc.pinA), j3EncoderA, CHANGE);
  attachInterrupt(digitalPinToInterrupt(j4_enc.pinA), j4EncoderA, CHANGE);
  attachInterrupt(digitalPinToInterrupt(stop_z), j2EndstopISR, FALLING);
}


//관절 1에 대한 함수들 //////////////////////////////////////////////////////////////////////
void j1stepPulse() {
  if(!j1_run){ 
    digitalWrite(j1_pul, LOW); 
    return; 
  }
  digitalWrite(j1_pul, j1pulseState);
  j1pulseState = !j1pulseState;
}


void j1EncoderA() {//엔코더 읽기
  bool a = digitalRead(j1_enc.pinA);
  bool b = digitalRead(j1_enc.pinB);
  j1_enc.pos += (a == b) ? 1 : -1;
}

bool move_j1(float targetAngle, float tolDeg = 0.3f)
{
  float Angle = j1_gear * targetAngle;

  j1_run = true;

  noInterrupts();
  long Count = j1_enc.pos;
  interrupts();

  encod snap = j1_enc;
  snap.pos = Count;
  float nowAngle = encoder_getAngleDeg(&snap);

  float error  = Angle - nowAngle;
  float pidOut = pid_update(&j1_pid, error);

  float speed = fabs(pidOut);
  if (speed < 1) speed = 1;
  if (speed > 3500) speed = 3500;

  long interval = 1000000L / (2.0f * speed);
  
  noInterrupts();
  j1pulseInterval = interval;
  Timer1.setPeriod(j1pulseInterval);
  interrupts();

  digitalWrite(j1_dir, (pidOut > 0) ? LOW : HIGH);
  /*
  Serial.print("Angle="); Serial.print(nowAngle);
  Serial.print(" Error="); Serial.print(error);
  Serial.print(" speed="); Serial.print(speed);
  Serial.print(" interval(us)="); Serial.println(interval);
*/
  if (fabs(error) <= j1_gear * tolDeg) {
    j1_run = false;              
    digitalWrite(j1_pul, LOW);   
    return true;                 
  }
  return false;  
}

static float j1_now_deg() // 현재 각도값 저장하는 함수
{
  noInterrupts();
  long c = j1_enc.pos;
  interrupts();

  encod snap = j1_enc;
  snap.pos = c;
  return encoder_getAngleDeg(&snap);
}

static float j1_error_deg(float targetAngle) //현재 오차값 저장하는 함수
{
  return (j1_gear * targetAngle) - j1_now_deg();
}

void move_j1_wait(float targetAngle,
                  float tolDeg = 1.0f,
                  unsigned long stable_ms = 150,
                  unsigned long timeout_ms = 80000) //연속동작 가능
{
  unsigned long t0 = millis();
  unsigned long inTolSince = 0;

  motors_enable_all(true);

  while (true) {
    move_j1(targetAngle);                 

    float e = j1_error_deg(targetAngle);
    if (fabs(e) <j1_gear* tolDeg) {
      if (inTolSince == 0) inTolSince = millis();
      if (millis() - inTolSince >= stable_ms) break;
    } else {
      inTolSince = 0;
    }

    if (millis() - t0 > timeout_ms) break;
  }

  // 정지(필요하면)
  j1_run = false;
  digitalWrite(j1_pul, LOW);
  motors_enable_all(false);
}

static void j1_set_pps(unsigned long pps) {
  if (pps < 1) pps = 1;
  unsigned long isr_us = 1000000UL / (2 * pps);  // 토글이라 2배
  //if (isr_us < 50) isr_us = 50;                  // 너무 빠른 값 방지(필요시 조절)
  noInterrupts();
  Timer1.setPeriod(isr_us);
  interrupts();
  j1_run = true;
}
void enc_reset_j1()
{
  noInterrupts();
  j1_enc.pos = 0;
  interrupts();
}

void j1_home_stop_on_switch(bool dir_to_switch, unsigned long pps)
{
  motors_enable_all(true);

  auto setDirToward = [&](bool toward){
    digitalWrite(j1_dir, toward ? HIGH : LOW);
  };

  setDirToward(dir_to_switch);
  j1_set_pps(pps);
  j1_run = true;

  unsigned long t0 = millis();
  const unsigned long TIMEOUT_MS = 5000;
  const unsigned long STABLE_LOW_MS = 20;

  while (true) {
    if (millis() - t0 > TIMEOUT_MS) {
      j1_run = false;
      digitalWrite(j1_pul, LOW);
      motors_enable_all(false);
      return;
    }

    if (digitalRead(stop_j1) == LOW) {
      waitStableLow(stop_j1, STABLE_LOW_MS);
      break;
    }

    //delay(1);
  }

  j1_run = false;
  digitalWrite(j1_pul, LOW);

  enc_reset_j1();
  motors_enable_all(false);
}

///////////////////////////////////////////////////////////////////////////////////////////////

//관절 2에 대한 함수들 /////////////////////////////////////////////////////////////////////////
static inline void j2_enable(bool on)
{
  pinMode(j2_en, OUTPUT);
  digitalWrite(j2_en, on ? LOW : HIGH);
  // active level이 반대면 HIGH/LOW 뒤집으십시오.
}

void j2StepOnce(unsigned long pps)
{
  if (pps < 1) pps = 1;

  unsigned long period = 1000000UL / pps;
  if (period <= PULSE_US + 5) period = PULSE_US + 5;

  digitalWrite(STEP_PIN, HIGH);
  delayMicroseconds(PULSE_US);
  digitalWrite(STEP_PIN, LOW);
  delayMicroseconds(period - PULSE_US);
}
void move_j2_continuous(bool dir, unsigned long pps)
{
  j2_enable(true);

  digitalWrite(DIR_PIN, dir ? HIGH : LOW);
  delayMicroseconds(50);

  digitalWrite(STEP_PIN, LOW);

  j2_run = true;

  while (j2_run) {
    j2StepOnce(pps);
  }

  digitalWrite(STEP_PIN, LOW);
  //j2_enable(false);
}

void stop_j2_motion(bool disable_after = false)
{
  j2_run = false;
  digitalWrite(STEP_PIN, LOW);

  if (disable_after) {
    j2_enable(false);
  }
}
bool move_j2(float deg, unsigned long pps)
{
  long steps = (long)(fabs(deg) * (float)PULSES_PER_REV / 360.0f);
  bool dir = (deg >= 0);

  j2_enable(true);

  digitalWrite(DIR_PIN, dir ? HIGH : LOW);
  delayMicroseconds(50);
  digitalWrite(STEP_PIN, LOW);

  for (long i = 0; i < steps; i++) {
    j2StepOnce(pps);
  }

  digitalWrite(STEP_PIN, LOW);
  return true;
}

void j2EndstopISR(){
  j2_endstop_hit = true;   // ISR은 플래그만!
}
/////////////////////////////////////////////////////////////////////////////////////////////

//관절 3에 대한 함수들////////////////////////////////////////////////////////////////////////
void j3stepPulse() {//펄스 생성 코드
   if(!j3_run){ 
    digitalWrite(j3_pul, LOW); 
    return; 
   }            
  digitalWrite(j3_pul, j3pulseState);
  j3pulseState = !j3pulseState;
}
void j3EncoderA() {
  bool a = digitalRead(j3_enc.pinA);
  bool b = digitalRead(j3_enc.pinB);
  j3_enc.pos += (a == b) ? 1 : -1;
}

bool move_j3(float targetAngle, float tolDeg = 0.1f)
{
  float Angle = j3_gear * targetAngle;

  j3_run = true;

  noInterrupts();
  long Count = j3_enc.pos;
  interrupts();

  encod snap = j3_enc;
  snap.pos = Count;
  float nowAngle = encoder_getAngleDeg(&snap);

  float error  = Angle - nowAngle;
  float pidOut = pid_update(&j3_pid, error);
  
  if (fabs(error) <= j3_gear * tolDeg) {
    noInterrupts();
    j3_run = false;
    j3pulseState = LOW;
    digitalWrite(j3_pul, LOW);
    Timer4.stop();
    motors_enable_all(false);
    interrupts();
    return true;
  }

  float speed = fabs(pidOut);
  if (speed < 1) speed = 1;
  if (speed > 5500) speed = 5500;

  long interval = 1000000L / (2.0f * speed);

  noInterrupts();
  j3pulseInterval = interval;
  Timer4.setPeriod(j3pulseInterval);
  interrupts();

  digitalWrite(j3_dir, (pidOut > 0) ? LOW : HIGH);
  return false;  
}
static float j3_now_deg() // 현재 각도값 저장하는 함수
{
  noInterrupts();
  long c = j3_enc.pos;
  interrupts();

  encod snap = j3_enc;
  snap.pos = c;
  return encoder_getAngleDeg(&snap);
}

static float j3_error_deg(float targetAngle) //현재 오차값 저장하는 함수
{
  return (j3_gear * targetAngle) - j3_now_deg();
} 
void move_j3_wait(float targetAngle,
                  float tolDeg = 1.0f,
                  unsigned long stable_ms = 150,
                  unsigned long timeout_ms = 8000)
{
  unsigned long t0 = millis();
  unsigned long inTolSince = 0;

  motors_enable_all(true);

  while (true) {
    bool reached = move_j3(targetAngle, tolDeg);

    if (reached) {
      if (inTolSince == 0) inTolSince = millis();
      if (millis() - inTolSince >= stable_ms) break;
    } else {
      inTolSince = 0;
    }

    if (millis() - t0 > timeout_ms) break;
  }

  noInterrupts();
  j3_run = false;
  j3pulseState = LOW;
  digitalWrite(j3_pul, LOW);
  motors_enable_all(false);
  interrupts();

  motors_enable_all(false);
}
static void j3_set_pps(unsigned long pps) {
  if (pps < 1) pps = 1;
  unsigned long isr_us = 1000000UL / (2 * pps);  // 토글이라 2배
  if (isr_us < 50) isr_us = 50;                  // 너무 빠른 값 방지(필요시 조절)
  noInterrupts();
  Timer4.setPeriod(isr_us);
  interrupts();
  j3_run = true;
}

// stop 핀에서 LOW가 stable_ms 동안 "연속" 유지될 때만 true
static bool waitStableLow(uint8_t pin, unsigned long stable_ms)
{
  unsigned long t_start = millis();

  while (millis() - t_start < stable_ms) {
    if (digitalRead(pin) != LOW) {
      // 중간에 HIGH가 한번이라도 나오면 다시 처음부터
      t_start = millis();
    }
    //delay(1); // 1ms 샘플링(너무 빡세게 돌리면 오히려 노이즈에 취약)
  }
  return true;
}

// stop 핀에서 HIGH가 stable_ms 동안 연속 유지될 때 true (눌림 해제 확인용)
static bool waitStableHigh(uint8_t pin, unsigned long stable_ms, unsigned long timeout_ms = 1000)
{
  unsigned long t0 = millis();
  unsigned long t_start = millis();

  while (true) {
    if (digitalRead(pin) == HIGH) {
      if (millis() - t_start >= stable_ms) return true;
    } else {
      t_start = millis();
    }

    if (millis() - t0 > timeout_ms) return false;
    //delay(1);
  }
}
void enc_reset_j3()
{
  noInterrupts();
  j3_enc.pos = 0;
  interrupts();
}
void j3_home_stop_on_switch(bool dir_to_switch, unsigned long pps)
{
  motors_enable_all(true);

  auto setDirToward = [&](bool toward){
    digitalWrite(j3_dir, toward ? HIGH : LOW);
  };

  setDirToward(dir_to_switch);

  noInterrupts();
  j3pulseState = LOW;
  j3_run = false;
  interrupts();

  j3_set_pps(pps);
  j3_run = true;

  unsigned long t0 = millis();
  const unsigned long TIMEOUT_MS = 5000;

  while (true) {
    if (millis() - t0 > TIMEOUT_MS) {
      noInterrupts();
      j3_run = false;
      j3pulseState = LOW;
      digitalWrite(j3_pul, LOW);
      interrupts();
      motors_enable_all(false);
      return;
    }

    if (digitalRead(stop_j3) == LOW) {
      noInterrupts();
      j3_run = false;
      j3pulseState = LOW;
      digitalWrite(j3_pul, LOW);
      interrupts();
      break;
    }
  }

  //delay(20);   // 필요하면 정지 후 안정화 대기
  enc_reset_j3();
  motors_enable_all(false);
}
////////////////////////////////////////////////////////////////////////////////////////////

//관절 4에 대한 함수들//////////////////////////////////////////////////////////////////////
volatile long j4_step_edges = 0;

void j4stepPulse() {
  if(!j4_run){
    digitalWrite(j4_pul, LOW);
    return;
  }
  digitalWrite(j4_pul, j4pulseState);
  // 상승엣지(LOW->HIGH)에서만 1 step으로 카운트
  if (j4pulseState == HIGH) j4_step_edges++;
  j4pulseState = !j4pulseState;
}

void j4EncoderA() {
  bool a = digitalRead(j4_enc.pinA);
  bool b = digitalRead(j4_enc.pinB);
  j4_enc.pos += (a == b) ? 1 : -1;
}

bool move_j4(float targetAngle, float tolDeg = 0.3f)
{
  float Angle = j4_gear * targetAngle;

  j4_run = true;

  noInterrupts();
  long Count = j4_enc.pos;
  interrupts();

  encod snap = j4_enc;
  snap.pos = Count;
  float nowAngle = encoder_getAngleDeg(&snap);

  float error = Angle - nowAngle;
  float pidOut = pid_update(&j4_pid, error);

  float speed = fabs(pidOut);
  if (speed < 1) speed = 1;
  if (speed > 2000) speed = 2000;

  long interval = 1000000L / (2.0f * speed);

  noInterrupts();
  j4pulseInterval = interval;
  Timer5.setPeriod(j4pulseInterval);
  interrupts();

  digitalWrite(j4_dir, (pidOut > 0) ? LOW : HIGH);
/*
  Serial.print("Angle="); Serial.print(nowAngle);
  Serial.print(" Error="); Serial.print(error);
  Serial.print(" speed="); Serial.print(speed);
  Serial.print(" interval(us)="); Serial.println(interval);
*/
  if (fabs(error) <= j4_gear * tolDeg) {
    j4_run = false;              
    digitalWrite(j4_pul, LOW);   
    return true;                 
  }
  return false;  
}

static float j4_now_deg() // 현재 각도값 저장하는 함수
{
  noInterrupts();
  long c = j4_enc.pos;
  interrupts();

  encod snap = j4_enc;
  snap.pos = c;
  return encoder_getAngleDeg(&snap);
}

static float j4_error_deg(float targetAngle) //현재 오차값 저장하는 함수
{
  return (j4_gear * targetAngle) - j4_now_deg();
} 

void move_j4_wait(float targetAngle,
                  float tolDeg = 1.0f,
                  unsigned long stable_ms = 150,
                  unsigned long timeout_ms = 8000)
{
  unsigned long t0 = millis();
  unsigned long inTolSince = 0;

  motors_enable_all(true);

  while (true) {
    move_j4(targetAngle, tolDeg);

    float e = j4_error_deg(targetAngle);
    if (fabs(e) <= j4_gear * tolDeg) {
      if (inTolSince == 0) inTolSince = millis();
      if (millis() - inTolSince >= stable_ms) break;
    } else {
      inTolSince = 0;
    }

    if (millis() - t0 > timeout_ms) break;

    //delay(5);
  }

  j4_run = false;
  digitalWrite(j4_pul, LOW);

  motors_enable_all(false);
}


static void j4_set_pps(unsigned long pps) { 
  if (pps < 1) pps = 1; unsigned long isr_us = 1000000UL / (2 * pps); // 토글이라 2배 if (isr_us < 50) isr_us = 50; // 너무 빠른 값 방지(필요시 조절)
  noInterrupts(); 
  Timer5.setPeriod(isr_us); 
  interrupts();
  j4_run = true; 
}

bool j4_home_stop_on_switch_safe(bool dir_to_switch, unsigned long pps)
{
  motors_enable_all(true);

  auto setDirToward = [&](bool toward){
    digitalWrite(j4_dir, toward ? HIGH : LOW);
  };

  // 1) 스위치 쪽으로 접근(눌릴 때까지), timeout 필수
  setDirToward(dir_to_switch);
  
  noInterrupts();
  j4pulseState = LOW;
  j4_run = false;
  interrupts();
  
  j4_set_pps(pps);
  j4_run = true;
  
  unsigned long t0 = millis();
  const unsigned long TIMEOUT_MS = 5000;

  while (true) {
    if (millis() - t0 > TIMEOUT_MS) {
      noInterrupts();
      j4_run = false;
      j4pulseState = LOW;
      digitalWrite(j4_pul, LOW);
      interrupts();
      motors_enable_all(false);
      return;
    }

    if (digitalRead(stop_j4) == LOW) {
      noInterrupts();
      j4_run = false;
      j4pulseState = LOW;
      digitalWrite(j4_pul, LOW);
      interrupts();
      break;
    }
  }

  //delay(20);   // 필요하면 정지 후 안정화 대기
  enc_reset_j4();
  motors_enable_all(false);

}


void enc_reset_j4()
{
  noInterrupts();
  j4_enc.pos = 0;
  interrupts();
}
////////////////////////////////////////////////////////////////////////////////

// 스텝모터 enable
static inline void j1_enable(bool on)
{
  pinMode(j1_en, OUTPUT);
  digitalWrite(j1_en, on ? (EN_ACTIVE_LOW ? LOW : HIGH)
                        : (EN_ACTIVE_LOW ? HIGH : LOW));
}
static inline void j3_enable(bool on)
{
  pinMode(j3_en, OUTPUT);
  digitalWrite(j3_en, on ? (EN_ACTIVE_LOW ? LOW : HIGH)
                        : (EN_ACTIVE_LOW ? HIGH : LOW));
}
static inline void j4_enable(bool on)
{
  pinMode(j4_en, OUTPUT);
  digitalWrite(j4_en, on ? (EN_ACTIVE_LOW ? LOW : HIGH)
                        : (EN_ACTIVE_LOW ? HIGH : LOW));
}
static inline void motors_enable_all(bool on) // 전체 en
{
  j1_enable(on);
  j3_enable(on);
  //j4_enable(on);
  //pinMode(j2_en, OUTPUT);
  digitalWrite(j4_enable, on ? (EN_ACTIVE_LOW ? LOW : HIGH)
                        : (EN_ACTIVE_LOW ? HIGH : LOW));
}


////////////////////////////////////////////////////////////////////////////

//========조인트 값 받기=================================================

float j1_getJointDeg()
{
  noInterrupts();
  long c = j1_enc.pos;
  interrupts();

  encod snap = j1_enc;
  snap.pos = c;

  float motor_deg = encoder_getAngleDeg(&snap); // 모터축 각도(기존 로직)
  return motor_deg / (float)j1_gear;            // 조인트각 = 모터각 / 기어비
}

float j3_getJointDeg()
{
  noInterrupts();
  long c = j3_enc.pos;
  interrupts();

  encod snap = j3_enc;
  snap.pos = c;

  float motor_deg = encoder_getAngleDeg(&snap);
  return motor_deg / (float)j3_gear;
}

float j4_getJointDeg()
{
  noInterrupts();
  long c = j4_enc.pos;
  interrupts();

  encod snap = j4_enc;
  snap.pos = c;

  float motor_deg = encoder_getAngleDeg(&snap); // 모터축 각도(기존 로직)
  return motor_deg / (float)j4_gear;            // 조인트각 = 모터각 / 기어비
}
//===========================================================================

void enc_reset_all()
{
  noInterrupts();
  j1_enc.pos = 0;
  j3_enc.pos = 0;
  j4_enc.pos = 0;
  interrupts();
}

// ================== rail pulse ISR ==================
void railStepPulse()
{
  if (!rail_run) {
    digitalWrite(rail_pul, LOW);
    return;
  }

  digitalWrite(rail_pul, railPulseState);
  railPulseState = !railPulseState;
}

// ================== rail 속도 설정 ==================
void rail_set_pps(unsigned long pps)
{
  if (pps < 1) pps = 1;

  unsigned long isr_us = 1000000UL / (2UL * pps);  // 토글 기반이라 2배
  if (isr_us < 50) isr_us = 50;                    // 너무 빠른 값 방지

  noInterrupts();
  railPulseInterval = isr_us;
  Timer3.setPeriod(railPulseInterval);
  interrupts();
}

// ================== rail 시작 ==================
void moveRail(unsigned long pps, bool dir)
{
  pinMode(rail_pul, OUTPUT);
  pinMode(rail_dir, OUTPUT);
  pinMode(rail_en, OUTPUT);

  digitalWrite(rail_dir, dir ? HIGH : LOW);
  digitalWrite(rail_en, HIGH);   // 현재 코드 기준 enable active HIGH 가정
  digitalWrite(rail_pul, LOW);

  noInterrupts();
  railPulseState = LOW;
  rail_run = false;
  interrupts();

  rail_set_pps(pps);

  noInterrupts();
  rail_run = true;
  interrupts();
}

// ================== rail 정지 ==================
void stopRail(bool disable_after)
{
  noInterrupts();
  rail_run = false;
  railPulseState = LOW;
  interrupts();

  digitalWrite(rail_pul, LOW);

  if (disable_after) {
    digitalWrite(rail_en, LOW);   // 현재 코드 기준 disable
  }
}